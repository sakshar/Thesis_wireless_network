/**
 * Created by Laboni on 3/24/2018.
 */
public class SensorOrientation {
    int SensorId;
    int Orientation;
    int countingNULL=0; //newlyadded
}
