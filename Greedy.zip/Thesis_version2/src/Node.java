/**
 * Created by Laboni on 3/31/2018.
 */
public class Node {
    int sensorId;
    int orientation;
    int conflictCost;
    int totalConflict;
}
