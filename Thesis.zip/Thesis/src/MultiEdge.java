import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Laboni on 3/24/2018.
 */
public class MultiEdge {
    HashMap<Integer,Integer>edgeIntegerHashMap=new HashMap<>();
}
