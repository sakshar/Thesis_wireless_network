/**
 * Created by Asus on 3/17/2018.
 */
public class GraphEdge {
    GraphNode graphNode1;
    GraphNode graphNode2;

    GraphEdge(){}

    GraphEdge(GraphNode n1, GraphNode n2){
        this.graphNode1 = n1;
        this.graphNode2 = n2;
    }

    public String toString(){
        return "[ "+graphNode1+", "+graphNode2+ " ]";
    }
}
