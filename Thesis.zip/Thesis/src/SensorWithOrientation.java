import java.util.ArrayList;

/**
 * Created by Laboni on 3/16/2018.
 */
public class SensorWithOrientation {
    int numberOftagetsCovered;
    int orientation;
    int sensorID;
   // Target[] targetList;
    ArrayList<Target>targetArrayList;
}
