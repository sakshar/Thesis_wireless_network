import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * Created by Asus on 3/17/2018.
 */
public class MultiGraph {
    ArrayList<GraphNode> nodes;
    //PriorityQueue<GraphNode> nodes;
    ArrayList<GraphEdge> edges;
    Deployment deployment;

    MultiGraph(){
        //nodes = new PriorityQueue<>(fComparator);
        nodes = new ArrayList<>();
        edges = new ArrayList<>();
    }

    MultiGraph(ArrayList<GraphNode> nodes, ArrayList<GraphEdge> edges, Deployment deployment){
        //this.nodes = new PriorityQueue<>(fComparator);
        this.nodes = new ArrayList<>();
        this.edges = new ArrayList<>();
        this.deployment = deployment;
        for(GraphNode node: nodes){
            this.nodes.add(node);
        }
        for(GraphEdge edge: edges){
            this.edges.add(edge);
        }
    }
    MultiGraph(Deployment deployment){
        this.nodes = new ArrayList<>();
        this.edges = new ArrayList<>();
        this.deployment = deployment;
        int n = (int) (360/deployment.sensorArrayList.get(0).theta);

        for(Sensor sensor: deployment.sensorArrayList){
            for(int i = 0; i<n; i++)
                nodes.add(new GraphNode(sensor,i));
        }
    }

   /* public void generateMultiGraph(){
        for(Target target: deployment.targetArrayList){
            int size = target.sensorWithOrientation.size();
            if(size == 0) continue;
            else if(size == 1){
                GraphNode n = target.sensorWithOrientation.get(0);
                edges.add(new GraphEdge(n,n));
                nodes.get(nodes.indexOf(n)).degree++;
                nodes.get(nodes.indexOf(n)).loop++;
            }
            else {
                for(int i = 0; i<size; i++){
                    GraphNode n1 = target.sensorWithOrientation.get(i);
                    for(int j = i+1; j<size; j++){
                        GraphNode n2 = target.sensorWithOrientation.get(j);
                        edges.add(new GraphEdge(n1,n2));
                        //System.out.println("====checking:  "+n1);
                        nodes.get(nodes.indexOf(n1)).degree++;
                        nodes.get(nodes.indexOf(n2)).degree++;
                    }
                }
            }
        }
    }*/

    public void graphSolve(){
        this.nodes.sort(fComparator);
        ArrayList<GraphNode> activeSensorsWithOrientation = new ArrayList<>();
        ArrayList<Target> targetsUncovered = new ArrayList<>();
        for(Target target: deployment.targetArrayList)
            targetsUncovered.add(target);
        ArrayList<Sensor> inactiveSensors = new ArrayList<>();
        for(Sensor sensor: deployment.sensorArrayList)
            inactiveSensors.add(sensor);

        // a copy of graph nodes array list
        ArrayList<GraphNode> currentNodes = new ArrayList<>();
        for(GraphNode graphNode: nodes) currentNodes.add(graphNode);

        for(GraphNode graphNode: currentNodes){
            // adding the current node to active sensor list
            activeSensorsWithOrientation.add(graphNode);
            ArrayList<Target> targets = graphNode.sensor.inRangeTargets[graphNode.orientation];

            //removing the targets from all the sensors
            for(Target target: targets ){
                targetsUncovered.remove(target);
            }

            //removing all the nodes of current sensor that is added to the active list
            for(GraphNode graphNode1: currentNodes){
                if(graphNode1.sensor.sensorID == graphNode.sensor.sensorID)
                    currentNodes.remove(graphNode1);
            }

        }
    }

    //Comparator anonymous class implementation
    public static Comparator<GraphNode> fComparator = new Comparator<GraphNode>(){

        @Override
        public int compare(GraphNode n1, GraphNode n2)
        {
            if(n1.loop > n2.loop) return 1;
            else if(n1.loop == n2.loop) {
                if(n1.degree > n2.degree)
                    return 1;
                else if(n1.degree == n2.degree)
                    return 0;
            }
            return -1;
        }
    };
}
