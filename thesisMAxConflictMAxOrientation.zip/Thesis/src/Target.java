import java.util.ArrayList;

/**
 * Created by Laboni on 1/30/2018.
 */
public class Target {
    double x;
    double y;
    int targetID;
    //ArrayList<GraphNode> sensorWithOrientation;
    ArrayList<SensorOrientation> sensorOrientations=new ArrayList<>();

    Target(){
        //sensorWithOrientation = new ArrayList<>();
    }

    Target(double x, double y, int targetID){
        this.x = x;
        this.y = y;
        this.targetID = targetID;
        //this.sensorWithOrientation = new ArrayList<>();
    }
    public String toString()
    {
        return "ID: "+targetID+" x: "+x+" y: "+y+"\n";
    }
}
