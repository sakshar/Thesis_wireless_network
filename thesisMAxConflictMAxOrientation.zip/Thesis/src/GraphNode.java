/**
 * Created by Asus on 3/17/2018.
 */
public class GraphNode {
    Sensor sensor;
    int orientation;
    int degree;
    int loop;

    GraphNode(){}

    GraphNode(Sensor sensor, int orientation){
        this.sensor = sensor;
        this.orientation = orientation;
        this.degree = 0;
        this.loop = 0;
    }

    public String toString(){
        return "< "+sensor.sensorID+", "+orientation+" > ";
    }

    @Override
    public boolean equals(Object object){
        if (object != null && object instanceof GraphNode)
        {
            if(this.sensor.sensorID == ((GraphNode) object).sensor.sensorID && this.orientation == ((GraphNode) object).orientation)
                return true;
        }
        return false;
    }
}
